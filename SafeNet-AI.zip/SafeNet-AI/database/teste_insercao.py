# Inserção simulada de dados no Oracle
print('Inserção de dados em Oracle 23ai')