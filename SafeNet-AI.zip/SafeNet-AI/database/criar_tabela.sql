-- Script SQL para criar tabela
CREATE TABLE sensores (
  id NUMBER PRIMARY KEY,
  temperatura FLOAT,
  umidade FLOAT,
  data_hora TIMESTAMP
);