# Streamlit Dashboard
import streamlit as st
st.title('SafeNet-AI Dashboard')
st.write('Visualização dos dados ambientais')