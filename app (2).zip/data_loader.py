# data_loader.py
import streamlit as st
import pandas as pd
from pathlib import Path
import config
import glob

@st.cache_data
def carregar_dados_finais():
    # ... (código inalterado) ...
    try:
        script_dir = Path(__file__).resolve().parent
        caminho_arquivo = script_dir / config.NOME_ARQUIVO_EXCEL
        if not caminho_arquivo.exists():
            return None, f"ERRO: Arquivo '{config.NOME_ARQUIVO_EXCEL}' não encontrado."
        nomes_colunas_iis = ['Código Município', 'Município', 'UF', 'Região', 'Classe', 'Valor IIS']
        df_iis = pd.read_excel(caminho_arquivo, sheet_name="IIS", header=None, usecols=range(6), names=nomes_colunas_iis)
        df_iis['Classe'] = pd.to_numeric(df_iis['Classe'], errors='coerce').fillna(0).astype(int)
        df_classes_raw = pd.read_excel(caminho_arquivo, sheet_name="Classes de seca")
        df_classes_raw.rename(columns={df_classes_raw.columns[0]: 'raw'}, inplace=True)
        df_classes_raw['Classe'] = df_classes_raw['raw'].str.split(' - ').str[0].astype(int)
        df_classes_raw['Descrição da Classe'] = df_classes_raw['raw'].str.split(' - ').str[1]
        df_classes = df_classes_raw[['Classe', 'Descrição da Classe']]
        df_completo = pd.merge(df_iis, df_classes, on='Classe', how='left')
        df_completo['Descrição da Classe'].fillna('Sem Seca', inplace=True)
        df_completo['Valor IIS'] = pd.to_numeric(df_completo['Valor IIS'], errors='coerce')
        dados_finais = df_completo[['UF', 'Município', 'Valor IIS', 'Classe', 'Descrição da Classe']]
        return dados_finais, None
    except Exception as e:
        return None, f"Ocorreu um erro inesperado ao processar o arquivo: {e}"

@st.cache_data
def carregar_dados_temporais():
    try:
        script_dir = Path(__file__).resolve().parent
        padrao_arquivos = f"{script_dir}/IIS_Brasil_*.xlsx"
        lista_arquivos = glob.glob(padrao_arquivos)

        if not lista_arquivos:
            return None, f"Nenhum arquivo de dados encontrado com o padrão 'IIS_Brasil_*.xlsx'."

        df_classes_raw = pd.read_excel(lista_arquivos[0], sheet_name="Classes de seca")
        df_classes_raw.rename(columns={df_classes_raw.columns[0]: 'raw'}, inplace=True)
        df_classes_raw['Classe'] = df_classes_raw['raw'].str.split(' - ').str[0].astype(int)
        df_classes_raw['Descrição da Classe'] = df_classes_raw['raw'].str.split(' - ').str[1]
        df_classes = df_classes_raw[['Classe', 'Descrição da Classe']]

        lista_dfs_mensais = []
        for arquivo in lista_arquivos:
            nome_arquivo_base = Path(arquivo).stem
            partes_nome = nome_arquivo_base.split('_')
            periodo = f"{partes_nome[2]}-{partes_nome[3]}"
            
            nomes_colunas_iis = ['Código Município', 'Município', 'UF', 'Região', 'Classe', 'Valor IIS']
            df_mes = pd.read_excel(arquivo, sheet_name="IIS", header=None, usecols=range(6), names=nomes_colunas_iis)
            df_mes['Classe'] = pd.to_numeric(df_mes['Classe'], errors='coerce').fillna(0).astype(int)
            df_mes['Período'] = periodo
            lista_dfs_mensais.append(df_mes)

        df_total = pd.concat(lista_dfs_mensais, ignore_index=True)
        df_final = pd.merge(df_total, df_classes, on='Classe', how='left')
        df_final['Descrição da Classe'].fillna('Sem Seca', inplace=True)
        
        # --- CORREÇÃO APLICADA AQUI ---
        # Corrigindo a ordenação para garantir que o DataFrame seja modificado
        df_final = df_final.sort_values(by='Período')

        return df_final, None

    except Exception as e:
        return None, f"Ocorreu um erro ao carregar os dados temporais: {e}"
