# pages/4_Descrição_do_Projeto.py

import streamlit as st

st.set_page_config(page_title="Descrição do Projeto", page_icon="📄", layout="wide")

st.title("📄 Documentação do Projeto: Sistema de Monitoramento de Seca")
st.markdown("*Versão 2.0 - Arquitetura com Oracle AI Database*")
st.markdown("---")

# --- Resumo Executivo ---
st.header("1. Resumo Executivo")
st.markdown("""
O presente projeto detalha a concepção e arquitetura de um **Sistema Integrado de Monitoramento e Análise de Seca (SIMAS)**. A solução foi projetada como um sistema de ponta a ponta, abrangendo desde a aquisição de dados em tempo real com dispositivos de Internet das Coisas (IoT) até a disponibilização de insights acionáveis através de um dashboard interativo.

O objetivo principal é fornecer a gestores de recursos hídricos, agrônomos e pesquisadores uma ferramenta robusta para o acompanhamento de indicadores de seca, análise de tendências históricas e, futuramente, a aplicação de modelos preditivos.

A arquitetura se baseia em um stack tecnológico moderno e escalável, utilizando **ESP32** para a coleta de dados, uma API **Flask** para a ingestão, o **Oracle Database 23ai Free** como repositório central de dados e inteligência, e o **Streamlit** para a camada de visualização.
""")
st.markdown("---")


# --- Arquitetura da Solução ---
st.header("2. Arquitetura da Solução")
st.caption("A arquitetura é dividida em quatro camadas lógicas, garantindo modularidade e escalabilidade.")
st.code("""
CAMADA DE COLETA (Hardware em Campo)
  └─ Microcontrolador ESP32 com Sensores (Umidade do Solo, Temperatura, Umidade do Ar)
         |
         | (Protocolo de comunicação: HTTPS POST com payload JSON)
         v
CAMADA DE INGESTÃO (Backend no Servidor Azure)
  └─ API RESTful com Python e Flask
         |
         | (Lógica de validação, transformação e autenticação)
         v
CAMADA DE PERSISTÊNCIA E IA (Banco de Dados)
  └─ Oracle Database 23ai Free
     ├─ Armazenamento de Séries Temporais e Dados Geoespaciais
     └─ Execução de análises e uso do AI Vector Search para buscas de similaridade
         |
         | (Consultas otimizadas com SQL e PL/SQL via biblioteca 'oracledb')
         v
CAMADA DE APRESENTAÇÃO (Frontend no Servidor Azure)
  └─ Dashboard Interativo com Streamlit
         |
         | (Acesso via Navegador Web)
         v
USUÁRIO FINAL (Analistas, Gestores, Pesquisadores)
""", language='text')
st.markdown("---")

# --- Detalhamento Tecnológico ---
st.header("3. Detalhamento Tecnológico (Technology Stack)")

st.subheader("3.1. Controlador ESP32: O Sensor Inteligente")
st.markdown("""
- **Tecnologia:** Microcontrolador de 32 bits da Espressif Systems com Wi-Fi integrado.
- **Função no Projeto:** Atua como o nó sensor autônomo. É programado para coletar dados de sensores ambientais (ex: umidade do solo) em intervalos regulares e transmiti-los via Wi-Fi para a nossa API, garantindo baixo consumo de energia e conectividade confiável.
""")

st.subheader("3.2. API Flask: O Gateway de Dados")
st.markdown("""
- **Tecnologia:** Micro-framework web em Python.
- **Função no Projeto:** Serve como um gateway seguro e eficiente para a entrada de dados no nosso sistema. Ele expõe um endpoint `/api/data` que recebe as requisições POST do ESP32, valida a estrutura do JSON recebido, e orquestra a inserção dos dados no Oracle Database.
""")

st.subheader("3.3. Oracle Database 23ai Free: O Cérebro Analítico")
st.markdown("""
- **Tecnologia:** Versão gratuita e para desenvolvedores do banco de dados convergente da Oracle, com recursos de Inteligência Artificial.
- **Função no Projeto:** É o coração do sistema, indo muito além do simples armazenamento.
    - **Persistência Robusta:** Garante a segurança e a integridade dos dados com transações ACID.
    - **Performance:** Otimizado para consultas complexas sobre grandes volumes de dados de séries temporais.
    - **Inteligência Artificial Integrada:** O recurso **AI Vector Search** é um diferencial estratégico. Ele permite a criação de "vetores" que representam numericamente os padrões de seca de um período. Com isso, podemos realizar consultas avançadas como: *"Encontre os 5 períodos históricos em qualquer localidade que tiveram um padrão de seca mais similar ao que estamos vendo em São Paulo hoje"*. Isso abre portas para análises comparativas e preditivas complexas diretamente no banco de dados.
    - **Flexibilidade:** O suporte nativo a JSON facilita o armazenamento dos dados brutos enviados pelo ESP32.
""")

st.subheader("3.4. Streamlit: A Interface Interativa")
st.markdown("""
- **Tecnologia:** Framework Python para criação de aplicações web de dados.
- **Função no Projeto:** Responsável por toda a experiência do usuário. Ele consulta os dados diretamente do Oracle Database (através do `data_loader`) e os transforma nos mapas, gráficos e tabelas interativas. Sua arquitetura modular permite a criação de múltiplas páginas com funcionalidades específicas (Visão Geral, Comparação, Análise Temporal).
""")
st.markdown("---")

# --- Funcionalidades do Dashboard ---
st.header("4. Funcionalidades Implementadas")
st.success("✔ **Dashboard Principal (Visão Geral):** Apresenta um mapa coroplético do Brasil com a média de intensidade da seca por estado, além de métricas nacionais e um gráfico de distribuição de municípios por nível de seca.")
st.success("✔ **Análise Temporal:** Permite a visualização da evolução da seca ao longo de meses/anos através de um mapa animado e gráficos de tendência de linha para estados específicos.")
st.success("✔ **Comparativo entre Estados:** Oferece uma visão lado a lado das métricas e da distribuição da seca para dois estados selecionados pelo usuário.")
st.success("✔ **Página de Configuração:** Descreve a infraestrutura de hardware e software que suporta a aplicação, garantindo transparência e reprodutibilidade.")
