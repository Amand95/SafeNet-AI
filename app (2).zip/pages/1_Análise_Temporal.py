# pages/1_Análise_Temporal.py
import streamlit as st
import plotly.express as px
from data_loader import carregar_dados_temporais
from visualizations import carregar_geojson_brasil

st.set_page_config(page_title="Análise Temporal", page_icon="📈", layout="wide")
st.title("📈 Análise Temporal da Seca")
st.markdown("Explore a evolução da seca no Brasil ao longo dos meses.")
st.markdown("---")

dados_temporais, erro_dados = carregar_dados_temporais()
geojson, erro_geojson = carregar_geojson_brasil()

if erro_dados:
    st.error(erro_dados)
elif erro_geojson:
    st.error(erro_geojson)
elif dados_temporais is not None:
    
    # --- 1. MAPA ESTÁTICO DE TESTE ---
    st.header("Mapa de Teste (Primeiro Mês)")
    st.info("Este é um teste para verificar se o mapa estático é renderizado corretamente.")

    # Pega o primeiro período disponível nos dados
    primeiro_periodo = dados_temporais['Período'].iloc[0]
    dados_primeiro_periodo = dados_temporais[dados_temporais['Período'] == primeiro_periodo]

    # Agrega os dados para o mapa
    dados_mapa = dados_primeiro_periodo.groupby('UF')['Classe'].mean().reset_index()

    # Cria o mapa ESTÁTICO (sem animação)
    fig_mapa_estatico = px.choropleth_mapbox(
        dados_mapa,
        geojson=geojson,
        locations='UF',
        featureidkey="properties.sigla",
        color='Classe',
        color_continuous_scale="YlOrRd",
        range_color=(0, 4),
        mapbox_style="carto-positron",
        zoom=3.3,
        center={"lat": -14.2350, "lon": -51.9253},
        opacity=0.6,
        title=f"Situação da Seca em: {primeiro_periodo}",
        labels={'Classe': 'Nível Médio'}
    )
    fig_mapa_estatico.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
    st.plotly_chart(fig_mapa_estatico, use_container_width=True)
    st.markdown("---")


    # --- 2. GRÁFICO DE TENDÊNCIA POR ESTADO ---
    # (O código do gráfico de linha continua o mesmo)
    st.header("Tendência de Seca por Estado")
    lista_estados = sorted(dados_temporais['UF'].unique())
    estado_selecionado = st.selectbox(
        "Selecione um Estado para ver a tendência:",
        options=lista_estados,
        index=lista_estados.index('SP') if 'SP' in lista_estados else 0
    )
    if estado_selecionado:
        dados_estado = dados_temporais[dados_temporais['UF'] == estado_selecionado]
        tendencia_estado = dados_estado.groupby('Período')['Classe'].mean().reset_index()
        fig_linha = px.line(
            tendencia_estado, x='Período', y='Classe',
            title=f'Evolução do Nível Médio de Seca em {estado_selecionado}',
            markers=True, labels={'Classe': 'Nível Médio de Seca', 'Período': 'Mês'}
        )
        fig_linha.update_yaxes(range=[0, 4])
        st.plotly_chart(fig_linha, use_container_width=True)

else:
    st.warning("Não foi possível carregar os dados temporais para exibir a análise.")
