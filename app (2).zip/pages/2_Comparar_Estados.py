# pages/2_Comparar_Estados.py
"""
Página da aplicação para comparar os dados de seca entre dois estados.
"""

import streamlit as st
import pandas as pd

# Importa as funções que já criamos nos outros módulos
from data_loader import carregar_dados_finais
from visualizations import criar_grafico_pizza_estado

def display_info_estado(coluna, dados_estado):
    """
    Função auxiliar para exibir as métricas e o gráfico de um estado em uma coluna.
    """
    nome_estado = dados_estado['UF'].iloc[0]
    
    # Filtra dados para cálculo
    dados_com_seca = dados_estado[dados_estado['Descrição da Classe'] != 'Sem Seca']
    nivel_medio_seca = dados_estado['Classe'].mean()

    # Exibe as métricas
    coluna.metric(f"Municípios Afetados em {nome_estado}", len(dados_com_seca))
    coluna.metric(f"Nível Médio de Seca em {nome_estado}", f"{nivel_medio_seca:.2f}")

    # Exibe o gráfico de pizza
    fig_pizza = criar_grafico_pizza_estado(dados_estado)
    coluna.pyplot(fig_pizza)

# --- Título da Página ---
st.set_page_config(page_title="Comparativo de Estados", page_icon="📊", layout="wide")
st.title("📊 Comparativo entre Estados")
st.markdown("Selecione dois estados para comparar lado a lado a situação da seca.")
st.markdown("---")

# --- Carregamento dos Dados ---
# Reutilizamos a mesma função do app principal
dados, erro_dados = carregar_dados_finais()

# A página só continua se os dados forem carregados
if erro_dados:
    st.error(erro_dados)
elif dados is not None:
    lista_estados = sorted(dados['UF'].unique())
    
    # --- Seleção dos Estados em Duas Colunas ---
    col1, col2 = st.columns(2)
    
    with col1:
        # Tenta encontrar o índice de 'SP', se não encontrar, usa o primeiro da lista (0)
        try:
            index_sp = lista_estados.index('SP')
        except ValueError:
            index_sp = 0
        estado_1 = st.selectbox(
            "Selecione o primeiro estado:",
            options=lista_estados,
            index=index_sp, # Deixa SP como padrão
            key="estado1"
        )

    with col2:
        # Tenta encontrar o índice de 'RJ', se não encontrar, usa o segundo da lista (1)
        try:
            index_rj = lista_estados.index('RJ')
        except ValueError:
            index_rj = 1
        estado_2 = st.selectbox(
            "Selecione o segundo estado:",
            options=lista_estados,
            index=index_rj, # Deixa RJ como padrão
            key="estado2"
        )
    
    st.markdown("---")

    # --- Verificação e Exibição da Comparação ---
    if estado_1 == estado_2:
        st.warning("Por favor, selecione dois estados diferentes para a comparação.")
    else:
        # Filtra os dados para cada estado selecionado
        dados_estado_1 = dados[dados['UF'] == estado_1]
        dados_estado_2 = dados[dados['UF'] == estado_2]

        # Usa as colunas novamente para exibir os resultados lado a lado
        comp_col1, comp_col2 = st.columns(2)
        
        with comp_col1:
            display_info_estado(comp_col1, dados_estado_1)
        
        with comp_col2:
            display_info_estado(comp_col2, dados_estado_2)
else:
    st.warning("Não foi possível carregar os dados para exibir a comparação.")
