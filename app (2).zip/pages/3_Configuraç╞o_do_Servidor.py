# pages/3_Configuracao_do_Servidor.py

import streamlit as st

st.set_page_config(page_title="Configuração do Servidor", page_icon="⚙️", layout="wide")

st.title("⚙️ Configuração do Servidor e Tecnologias")
st.markdown("""
Esta página detalha a infraestrutura de hardware e software utilizada para hospedar e executar esta aplicação de análise de dados. 
A transparência sobre o ambiente garante a reprodutibilidade e ajuda a entender o contexto da performance da análise.
""")
st.markdown("---")

# --- Seção de Infraestrutura ---
st.subheader("☁️ Infraestrutura de Hospedagem")
st.markdown("""
A aplicação está hospedada em uma **Máquina Virtual (VM)** na nuvem da **Microsoft Azure**.
- **Hostname do Servidor:** `GS`
- **Hypervisor (Tecnologia de Virtualização):** `Microsoft`
- **Endereço IP (Rede Interna):** `57.154.50.104`
- **Tempo de Atividade (Uptime):** `21 horas e 43 minutos` (no momento da coleta de dados)
""")
st.markdown("---")

# --- Seção de Hardware e SO ---
st.subheader("🖥️ Sistema Operacional e Hardware")
col1, col2, col3 = st.columns(3)
with col1:
    st.metric(label="Sistema Operacional", value="AlmaLinux 9.6")
    st.caption("Kernel: Linux 5.14.0")
with col2:
    st.metric(label="CPU", value="2 vCPUs")
    st.caption("Intel Xeon Platinum 8370C @ 2.80GHz")
with col3:
    st.metric(label="Memória RAM Total", value="7.4 GiB")
    st.caption("Arquitetura: x86_64")

st.markdown("##### Detalhes do Disco Principal (`/`)")
# O valor 41 vem da linha "Use%" do seu output do comando 'df -h'
st.progress(41, text="Uso de Disco: 26GiB de 63GiB (41%)")
st.markdown("---")


# --- Seção do Ambiente Python ---
st.subheader("🐍 Ambiente de Execução Python")
st.markdown(f"""
A aplicação roda dentro de um ambiente virtual **Conda** para garantir o isolamento e a consistência das dependências.
- **Nome do Ambiente:** `streamlit`
- **Versão do Conda:** `25.5.0`
- **Versão do Python:** `3.12.11`
""")
st.markdown("---")

# --- Seção das Bibliotecas ---
st.subheader("📚 Principais Bibliotecas Utilizadas")
st.markdown("""
O coração desta análise de dados é construído sobre um ecossistema de bibliotecas Python de código aberto. As mais importantes para este projeto são:
- **Streamlit (`1.45.1`):** Para a construção da interface web interativa.
- **Pandas (`2.3.0`):** Para a manipulação e processamento dos dados.
- **Plotly (`6.1.2`) & Matplotlib (`3.10.3`):** Para a criação das visualizações e gráficos.
- **Requests (`2.30.0`) & BeautifulSoup4 (`4.13.4`):** Para a coleta automatizada de dados (web scraping).
- **Openpyxl (`3.1.5`):** Para a leitura dos arquivos Excel.
""")

# Lista completa de pacotes dentro de um expander
pip_list_output = """
Package                   Version
------------------------- -----------
altair                    5.5.0
attrs                     25.3.0
beautifulsoup4            4.13.4
blinker                   1.9.0
Brotli                    1.1.0
cachetools                5.5.2
certifi                   2025.4.26
cffi                      1.17.1
charset-normalizer        3.4.2
click                     8.2.1
contourpy                 1.3.2
cryptography              45.0.3
cx_Oracle                 8.3.0
cycler                    0.12.1
et_xmlfile                2.0.0
fonttools                 4.58.2
gitdb                     4.0.12
GitPython                 3.1.44
greenlet                  3.2.3
h2                        4.2.0
hpack                     4.1.0
hyperframe                6.1.0
idna                      3.10
importlib_metadata        8.7.0
importlib_resources       6.5.2
Jinja2                    3.1.6
jsonschema                4.24.0
jsonschema-specifications 2025.4.1
kiwisolver                1.4.8
lxml                      5.4.0
MarkupSafe                3.0.2
matplotlib                3.10.3
narwhals                  1.41.0
numpy                     2.2.6
openpyxl                  3.1.5
oracledb                  3.1.1
packaging                 24.2
pandas                    2.3.0
pillow                    11.2.1
pip                       25.1.1
pkgutil_resolve_name      1.3.10
plotly                    6.1.2
protobuf                  5.29.3
pyarrow                   20.0.0
pycparser                 2.22
pydeck                    0.9.1
pyparsing                 3.2.3
PySocks                   1.7.1
python-dateutil           2.9.0.post0
pytz                      2025.2
PyYAML                    6.0.2
referencing               0.36.2
requests                  2.30.0
rpds-py                   0.25.1
setuptools                80.9.0
six                       1.17.0
smmap                     5.0.2
soupsieve                 2.7
SQLAlchemy                2.0.41
streamlit                 1.45.1
tenacity                  9.1.2
toml                      0.10.2
tornado                   6.5.1
typing_extensions         4.14.0
tzdata                    2025.2
urllib3                   2.4.0
watchdog                  6.0.0
wheel                     0.45.1
zipp                      3.22.0
zstandard                 0.23.0
"""

with st.expander("Ver lista completa de pacotes Python instalados"):
    st.code(pip_list_output, language='text')
