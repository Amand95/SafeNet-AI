# app.py
"""
Arquivo principal da aplicação Streamlit.
Este arquivo orquestra a chamada às funções de outros módulos
para carregar dados, criar visualizações e montar a interface do usuário.
"""

import streamlit as st
import config  # Nosso arquivo de configuração

# Importa as funções dos nossos módulos
from data_loader import carregar_dados_finais
from visualizations import (
    carregar_geojson_brasil,
    criar_mapa_brasil,
    criar_grafico_pizza_estado
)

# --- 1. CONFIGURAÇÃO DA PÁGINA ---
st.set_page_config(
    page_title="Monitor de Secas no Brasil",
    page_icon="💧",
    layout="wide"
)

# --- 2. TÍTULO E INTRODUÇÃO ---
st.title("💧 Monitor de Secas no Brasil")
st.markdown("Painel de análise interativo dos dados do Índice Integrado de Seca (IIS), com base nos dados de **Maio de 2025**.")
st.markdown("---")

# --- 3. CARREGAMENTO DOS DADOS ---
# Chama as funções para carregar os dados principais e o mapa
dados, erro_dados = carregar_dados_finais()
geojson, erro_geojson = carregar_geojson_brasil()

# --- 4. CONSTRUÇÃO DA PÁGINA ---
# A página só é construída se os dados foram carregados com sucesso
if erro_dados:
    st.error(erro_dados)
elif erro_geojson:
    st.error(erro_geojson)
elif dados is not None:
    # Seção do Mapa
    st.header("Mapa de Intensidade da Seca por Estado")
    mapa_fig = criar_mapa_brasil(dados, geojson)
    st.plotly_chart(mapa_fig, use_container_width=True)
    st.caption("A cor de cada estado representa a média da classe de seca de seus municípios. Quanto mais vermelho, mais intensa é a situação de seca na média do estado.")
    st.markdown("---")

    # Seção de Panorama Nacional
    st.header("Panorama Nacional")
    dados_com_seca = dados[dados['Descrição da Classe'] != 'Sem Seca']
    col1, col2 = st.columns(2)
    col1.metric("Total de Municípios Monitorados", len(dados))
    col2.metric("Municípios com Algum Nível de Seca", len(dados_com_seca))

    st.subheader("Distribuição de Municípios por Nível de Seca")
    if not dados_com_seca.empty:
        distribuicao_classes = dados_com_seca['Descrição da Classe'].value_counts().sort_index()
        st.bar_chart(distribuicao_classes, color=config.COR_GRAFICO_BARRAS)
    else:
        st.info("Nenhum município com seca identificado nos dados.")
    st.markdown("---")
    
    # Seção de Análise Estadual
    st.header("Análise Detalhada por Estado")
    lista_estados = sorted(dados['UF'].unique())
    estado_selecionado = st.selectbox("Selecione um Estado para filtrar os dados:", options=lista_estados)

    if estado_selecionado:
        dados_estado = dados[dados['UF'] == estado_selecionado]
        st.subheader(f"Situação em {estado_selecionado}")
        col_tabela, col_pizza = st.columns([0.6, 0.4])

        with col_tabela:
            st.markdown(f"**Tabela de municípios para {estado_selecionado}**")
            st.dataframe(
                dados_estado[['Município', 'Valor IIS', 'Descrição da Classe']],
                height=400, use_container_width=True, hide_index=True
            )
        with col_pizza:
            st.markdown(f"**Distribuição em {estado_selecionado}**")
            fig_pizza = criar_grafico_pizza_estado(dados_estado)
            st.pyplot(fig_pizza)

    # Seção de Dados Completos
    with st.expander("Visualizar Tabela de Dados Completa"):
        st.dataframe(dados, use_container_width=True, hide_index=True)
else:
    st.warning("A aplicação não pôde ser carregada pois os dados não foram encontrados ou processados.")
