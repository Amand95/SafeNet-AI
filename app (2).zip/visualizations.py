# visualizations.py
"""
Módulo para criar todas as visualizações (gráficos e mapas) da aplicação.
"""
import streamlit as st  # <-- CORREÇÃO: LINHA ADICIONADA
import plotly.express as px
import matplotlib.pyplot as plt
import json
import requests
import config

@st.cache_data
def carregar_geojson_brasil():
    """ Baixa e carrega o arquivo GeoJSON com as fronteiras dos estados do Brasil. """
    try:
        response = requests.get(config.URL_GEOJSON)
        response.raise_for_status()
        return json.loads(response.text), None
    except requests.exceptions.RequestException as e:
        return None, f"Falha ao baixar o mapa do Brasil: {e}"

def criar_mapa_brasil(dados, geojson):
    """
    Cria um mapa coroplético do Brasil, colorindo os estados pelo nível médio de seca.
    """
    if dados is None or geojson is None:
        return None
    
    dados_por_estado = dados.groupby('UF')['Classe'].mean().reset_index()
    dados_por_estado.rename(columns={'Classe': 'Nível Médio de Seca'}, inplace=True)

    fig = px.choropleth_mapbox(
        dados_por_estado,
        geojson=geojson,
        locations='UF',
        featureidkey="properties.sigla",
        color='Nível Médio de Seca',
        color_continuous_scale=config.ESCALA_COR_MAPA,
        range_color=(0, 4),
        mapbox_style="carto-positron",
        zoom=3.3,
        center={"lat": -14.2350, "lon": -51.9253},
        opacity=0.6,
        labels={'Nível Médio de Seca': 'Nível Médio'}
    )
    fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0}, mapbox_accesstoken=None)
    return fig

def criar_grafico_pizza_estado(dados_estado):
    """
    Cria um gráfico de pizza com a distribuição de classes de seca para um estado.
    """
    distribuicao_estado = dados_estado['Descrição da Classe'].value_counts()
    fig, ax = plt.subplots()
    ax.pie(distribuicao_estado, labels=distribuicao_estado.index, autopct='%1.1f%%', startangle=90)
    ax.axis('equal')
    return fig
