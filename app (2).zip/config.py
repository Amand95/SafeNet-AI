# config.py
"""
Arquivo de configurações centralizadas para o projeto.
"""

# --- Variáveis de Arquivos e URLs ---
NOME_ARQUIVO_EXCEL = "IIS_Brasil_2025_05.xlsx"
URL_GEOJSON = "https://raw.githubusercontent.com/codeforamerica/click_that_hood/master/public/data/brazil-states.geojson"

# --- Configurações de Visualização ---
COR_GRAFICO_BARRAS = "#C46210"
ESCALA_COR_MAPA = "YlOrRd"
